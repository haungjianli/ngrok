# binarydist

Package binarydist implements binary diff and patch as described on
<http://www.daemonology.net/bsdiff/>. It reads and writes files
compatible with the tools there.

Documentation at <https://godoc.org/github.com/kr/binarydist>.
